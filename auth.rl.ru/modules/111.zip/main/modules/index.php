<?php
namespace Modules\Main\Modules;

class index
{
    public function index($url)
    {
//Получение списка модулей и запуск
/*
topnav
banner
telecom_block
news_block
big_contact
footer
*/
    }
}