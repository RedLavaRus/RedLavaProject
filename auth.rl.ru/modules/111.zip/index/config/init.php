<?php
namespace Modules\Index\Config;

class Init
{
    public function install()
    {

    }
    public function delete()
    {
        
    }
}