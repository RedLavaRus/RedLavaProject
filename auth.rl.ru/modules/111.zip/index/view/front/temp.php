<!DOCTYPE HTML>
<html lang="ru">
    <head>
        
<?php echo \Core\Values\Val::returnHead("pre");?>
<?php echo \Core\Values\Val::returnHead(NULL);?>
<?php echo \Core\Values\Val::returnHead("post");?>
        

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <meta name="theme-color" content="#ff0000">

        <link rel="stylesheet" href="/res/css/default.css">
        <link rel="icon" sizes="192x192" href="">

    </head>
    <body>
<?php echo \Core\Values\Val::returnBody("pre");?>
<?php echo \Core\Values\Val::returnBody(NULL);?>
<?php echo \Core\Values\Val::returnBody("post");?>

    <header>

        <nav>
            <div class="flex2">
                <div class="logo">LOGO</div>
            </div>
            <div class="flex4 flex">
                <div class="nav_element">Магазин</div>
                <div class="nav_element">двыхсловный эеменет</div>
                <div class="nav_element">Мини</div>
                <div class="nav_element">Очень длинный</div>
                <div class="nav_element">РАЗДЕЛ1</div>
                <div class="nav_element">РАЗДЕЛ1</div>
            </div>
            <div class="flex4">
            </div>
            <div class="flex2 flex">
                <div class="login">ВХОД</div>
                <div class="reg">РЕГИСТРАЦИЯ</div>
            </div>
        </nav>

    </header>

    <main>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </main>

    <aside>
    </aside>


<?php echo \Core\Values\Val::returnFooter("pre");?>
<?php echo \Core\Values\Val::returnFooter(NULL);?>
<?php echo \Core\Values\Val::returnFooter("post");?>
    </body>
</html>