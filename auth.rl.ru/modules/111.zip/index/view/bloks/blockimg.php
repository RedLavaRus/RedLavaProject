    <div class="line3">
        <img src="/res/img/pc.png">
    </div>