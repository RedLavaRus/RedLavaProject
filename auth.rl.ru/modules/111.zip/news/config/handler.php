<?php
namespace Modules\News\Config;

class Handler
{
    
    public function index()
    {

    }
}