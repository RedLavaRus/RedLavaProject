<?php

$var = \Core\Show\View::$var;

echo '
<div class="tp_box">'.$var["tarifs"].'</div>';
?>

