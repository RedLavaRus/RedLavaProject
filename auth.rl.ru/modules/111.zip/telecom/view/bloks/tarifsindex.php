<?php

$var = \Core\Show\View::$var;

echo '
<div class="linsloge4">
Подключиться к ТТК в Краснодаре<br>
Подключим Интернет за 1 день
</div>
<div class="tp_box">'.$var["tarifs"].'</div>';
?>

