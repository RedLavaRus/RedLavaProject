<?php
namespace Modules\Blocks\Config;

class Handler
{
    
    public function index()
    {
    }
}