<?php
namespace Modules\Test\Config;

class Handler
{
    
    public function index()
    {
       
    }
}