<?php
namespace Modules\Test\Config;

class Init
{
    public function install()
    {

    }
    public function delete()
    {
        
    }
}