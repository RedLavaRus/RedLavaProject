<?php
?>
<!DOCTYPE HTML>
<html lang="ru">
    <head>
        <title>Test</title>

        <meta charset="UTF-8">
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#ff0000">
        <link rel="stylesheet" href="/res/css/default.css">
        <link rel="icon" sizes="192x192" href="">
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    </head>
    <body>





<a id="open_modal" href="#open">Открыть окно</a>
    <div id="modal" class="modal bounceIn">
    <div id="close_modal">+</div>
    <div class="modal_txt">

    <form method="post" action="">
        <p><input type="text" name="login" value="" placeholder="Логин"></p>
        <p><input type="password" name="password1" value="" placeholder="Пароль"></p>
        <p class="remember_me">
          <label>
            <input type="checkbox" name="remember_me" id="remember_me">
            Запомнить меня
          </label>
        </p>
        <p class="submit"><input type="submit" name="commit" value="Зарегистрироваться"></p>
      </form>

    </div>
</div>
        <script src="/res/js/windows.js"></script>





 

    