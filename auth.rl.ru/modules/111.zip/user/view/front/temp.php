<?php
//$test = new \Modu\User\Auth;
//$test -> auth("test","test","test");
echo 1;
?>